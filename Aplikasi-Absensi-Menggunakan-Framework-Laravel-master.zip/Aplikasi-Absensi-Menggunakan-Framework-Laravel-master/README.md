# Applikasi Absensi Sederhana menggunakan Laravel 5.4

Tutorial : https://www.youtube.com/playlist?list=PL9x5qrC0rB0lh2OjFLbdZjw-IozYtjK9w <br />
Facebook : http://fb.me/rizal.ofdraw
